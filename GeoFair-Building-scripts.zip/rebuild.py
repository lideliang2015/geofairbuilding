#!/usr/bin/env python3
"""
GeoFair-Building v1.0 一键重建脚本
运行此脚本将自动完成所有步骤：
1. 检查原始数据集
2. 预处理
3. 分层抽样生成最终测试集
"""

import subprocess
import sys
import os

SCRIPTS = [
    "split_dataset.py",
    "preprocess_whu.py",
    "preprocess_inria.py", 
    "preprocess_spacenet.py",
    "preprocess_whu_satellite.py",
    "preprocess_rio.py",
    "merge_and_sample.py",
]

def main():
    print("=" * 60)
    print("GeoFair-Building v1.0 重建脚本")
    print("=" * 60)
    print("此脚本将自动预处理并生成 GeoFair-Building v1.0 测试集")
    print("需要约 200GB 可用磁盘空间")
    print("-" * 60)
    
    response = input("是否继续? (y/n): ")
    if response.lower() != 'y':
        return
    
    for script in SCRIPTS:
        print(f"\n执行: {script}")
        result = subprocess.run([sys.executable, script])
        if result.returncode != 0:
            print(f"错误: {script} 执行失败")
            break
    
    print("\n✅ 完成！")

if __name__ == "__main__":
    main()