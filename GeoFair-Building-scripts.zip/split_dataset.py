import pandas as pd
from sklearn.model_selection import train_test_split
import os

df = pd.read_csv("GeoFair-Building-v1.0/metadata.csv")
indices = df.index.tolist()
train_val, test = train_test_split(indices, test_size=0.15, random_state=42, stratify=df['continent'])
train, val = train_test_split(train_val, test_size=0.176, random_state=42, stratify=df.loc[train_val, 'continent'])
df['split'] = 'train'
df.loc[val, 'split'] = 'val'
df.loc[test, 'split'] = 'test'
df.to_csv("GeoFair-Building-v1.0/splits.csv", index=False)
print(f"Train: {len(train)}, Val: {len(val)}, Test: {len(test)}")