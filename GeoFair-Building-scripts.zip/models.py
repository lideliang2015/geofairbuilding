import torch.nn as nn
import segmentation_models_pytorch as smp
from transformers import SegformerForSemanticSegmentation

class UNet(nn.Module):
    def __init__(self): super().__init__(); self.model = smp.Unet('resnet34', encoder_weights=None, classes=1)
    def forward(self, x): return self.model(x)

class SegFormerModel(nn.Module):
    def __init__(self): super().__init__(); self.model = SegformerForSemanticSegmentation.from_pretrained('nvidia/mit-b2', num_labels=1)
    def forward(self, x): return nn.functional.interpolate(self.model(x).logits, size=x.shape[-2:], mode='bilinear')

def get_model(name, device='cuda'):
    if name == 'unet': return UNet().to(device)
    elif name == 'segformer': return SegFormerModel().to(device)
    else: raise ValueError(f"Unknown model: {name}")