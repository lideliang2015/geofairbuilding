# WHU Aerial 预处理脚本
# 将 COCO JSON 转换为 512x512 瓦片
# 完整代码请查看 GitHub 仓库