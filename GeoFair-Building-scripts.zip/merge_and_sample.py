# 合并与分层抽样脚本
import pandas as pd
# 按大陆和 HDI 分层抽样至 960 样本