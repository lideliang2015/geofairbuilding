# SpaceNet 预处理脚本
# 处理 AOI_5 和 AOI_10