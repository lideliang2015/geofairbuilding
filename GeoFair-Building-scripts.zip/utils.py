import numpy as np
def compute_metrics(pred, target, th=0.5):
    p = (pred>th).astype(np.uint8).flatten()
    t = (target>0.5).astype(np.uint8).flatten()
    tp = np.sum((p==1)&(t==1)); fp = np.sum((p==1)&(t==0)); fn = np.sum((p==0)&(t==1))
    prec = tp/(tp+fp) if tp+fp>0 else 0
    rec = tp/(tp+fn) if tp+fn>0 else 0
    f1 = 2*prec*rec/(prec+rec) if prec+rec>0 else 0
    return {'f1':f1, 'precision':prec, 'recall':rec, 'iou':tp/(tp+fp+fn) if tp+fp+fn>0 else 0}