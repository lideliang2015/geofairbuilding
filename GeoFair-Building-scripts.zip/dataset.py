import os, pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms

class GeoFairDataset(Dataset):
    def __init__(self, root_dir, split='train', transform=None):
        splits = pd.read_csv(os.path.join(root_dir, "splits.csv"))
        meta = pd.read_csv(os.path.join(root_dir, "metadata.csv"))
        ids = splits[splits['split']==split]['tile_id'].tolist()
        self.meta = meta[meta['tile_id'].isin(ids)].reset_index()
        self.transform = transform
    def __len__(self): return len(self.meta)
    def __getitem__(self, idx):
        row = self.meta.iloc[idx]
        img = Image.open(os.path.join(self.root_dir, row['image_path'])).convert('RGB')
        lbl = Image.open(os.path.join(self.root_dir, row['label_path'])).convert('L')
        if self.transform:
            img = self.transform(img)
            lbl = transforms.ToTensor()(lbl)
        return img, (lbl>0.5).float(), {'tile_id':row['tile_id'], 'continent':row['continent'], 'hdi_level':row['hdi_level']}