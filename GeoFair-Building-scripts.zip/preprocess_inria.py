# Inria 预处理脚本
# 将 GeoTIFF 转换为 512x512 瓦片